package parkreservation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomerDashboardFrame extends JFrame {

    private JTextField nameField;
    private JTextField vehicleTypeField;
    private JTextField plateNumberField;
    private JComboBox<String> floorComboBox;
    private JButton bookButton;
    private JButton logoutButton;

    public CustomerDashboardFrame() {
        setTitle("Customer Dashboard");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Panel form booking parkir
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Fields untuk input data
        formPanel.add(new JLabel("Name:"));
        nameField = new JTextField();
        formPanel.add(nameField);

        formPanel.add(new JLabel("Vehicle Type (Bike/Car):"));
        vehicleTypeField = new JTextField();
        formPanel.add(vehicleTypeField);

        formPanel.add(new JLabel("Plate Number:"));
        plateNumberField = new JTextField();
        formPanel.add(plateNumberField);

        formPanel.add(new JLabel("Floor:"));
        String[] floors = {"1", "2", "3", "4", "5"}; // Contoh lantai
        floorComboBox = new JComboBox<>(floors);
        formPanel.add(floorComboBox);

        bookButton = new JButton("Book Parking Slot");
        formPanel.add(bookButton);

        logoutButton = new JButton("Logout");
        formPanel.add(logoutButton);

        mainPanel.add(formPanel, BorderLayout.CENTER);
        add(mainPanel);

        // Action listener untuk tombol book
        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String vehicleType = vehicleTypeField.getText();
                String plateNumber = plateNumberField.getText();
                String floor = (String) floorComboBox.getSelectedItem();

                if (name.isEmpty() || vehicleType.isEmpty() || plateNumber.isEmpty()) {
                    JOptionPane.showMessageDialog(CustomerDashboardFrame.this, "Please fill in all fields.");
                } else {
                    // Simpan data booking ke database
                    try (Connection conn = DatabaseConnection.getConnection()) {
                        String query = "INSERT INTO bookings (name, vehicle_type, plate_number, floor, status) VALUES (?, ?, ?, ?, 'pending')";
                        PreparedStatement stmt = conn.prepareStatement(query);
                        stmt.setString(1, name);
                        stmt.setString(2, vehicleType);
                        stmt.setString(3, plateNumber);
                        stmt.setString(4, floor);

                        int rowsInserted = stmt.executeUpdate();
                        if (rowsInserted > 0) {
                            JOptionPane.showMessageDialog(CustomerDashboardFrame.this, "Booking successful!");

                            // Reset fields
                            nameField.setText("");
                            vehicleTypeField.setText("");
                            plateNumberField.setText("");
                            floorComboBox.setSelectedIndex(0);

                            // Pindah ke Thank You Frame
                            dispose(); // Tutup Customer Dashboard
                            new ThankYouFrame().setVisible(true);
                        }
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(CustomerDashboardFrame.this, "Error saving booking: " + ex.getMessage());
                    }
                }
            }
        });

        // Action listener untuk tombol logout
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Tutup Customer Dashboard
                new LoginFrame().setVisible(true); // Kembali ke Login Frame
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomerDashboardFrame().setVisible(true));
    }
}
