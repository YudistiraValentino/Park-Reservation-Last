package parkreservation;

public class Reservation {
    private String customerName;
    private String vehicleType;
    private String plateNumber;
    private int floor;

    public Reservation(String customerName, String vehicleType, String plateNumber, int floor) {
        this.customerName = customerName;
        this.vehicleType = vehicleType;
        this.plateNumber = plateNumber;
        this.floor = floor;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public int getFloor() {
        return floor;
    }
}
