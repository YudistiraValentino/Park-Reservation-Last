package parkreservation;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        try {
            try ( // Mencoba untuk melakukan koneksi ke database
                    Connection conn = DatabaseConnection.getConnection()) {
                System.out.println("Connected to the database!");
                // Menutup koneksi setelah berhasil terkoneksi
            }

            // Menampilkan Login Frame setelah berhasil terkoneksi
            new LoginFrame().setVisible(true);

        } catch (SQLException e) {
            // Menangani kesalahan jika koneksi gagal
            System.out.println("Failed to connect: " + e.getMessage());
        }
    }
}

