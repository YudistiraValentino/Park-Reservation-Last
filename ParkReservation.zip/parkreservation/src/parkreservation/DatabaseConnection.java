package parkreservation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    public static Connection getConnection() throws SQLException {
        try {
            String url = "jdbc:mysql://localhost:3306/park_reservation"; // Ganti dengan nama database Anda
            String username = "root"; // Ganti dengan username database Anda
            String password = "1234"; // Ganti dengan password database Anda
            return DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            throw new SQLException("Database connection failed: " + e.getMessage());
        }
    }
}
