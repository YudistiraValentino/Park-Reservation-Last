package parkreservation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminDashboardFrame extends JFrame {

    private JTable pendingTable;
    private JTable acceptedTable;
    private DefaultTableModel pendingModel;
    private DefaultTableModel acceptedModel;
    private JButton acceptButton;
    private JButton deletePendingButton;
    private JButton deleteAcceptedButton;
    private JButton logoutButton;

    public AdminDashboardFrame() {
        setTitle("Admin Dashboard");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel mainPanel = new JPanel(new BorderLayout());
        add(mainPanel);

        // Tab untuk pending dan accepted bookings
        JTabbedPane tabbedPane = new JTabbedPane();

        // Panel Pending
        JPanel pendingPanel = new JPanel(new BorderLayout());
        pendingModel = new DefaultTableModel(new String[]{"ID", "Name", "Vehicle Type", "Plate Number", "Floor"}, 0);
        pendingTable = new JTable(pendingModel);
        JScrollPane pendingScrollPane = new JScrollPane(pendingTable);
        pendingPanel.add(pendingScrollPane, BorderLayout.CENTER);

        acceptButton = new JButton("Accept Booking");
        deletePendingButton = new JButton("Delete Booking");
        JPanel pendingButtonPanel = new JPanel();
        pendingButtonPanel.add(acceptButton);
        pendingButtonPanel.add(deletePendingButton);
        pendingPanel.add(pendingButtonPanel, BorderLayout.SOUTH);

        tabbedPane.addTab("Pending Bookings", pendingPanel);

        // Panel Accepted
        JPanel acceptedPanel = new JPanel(new BorderLayout());
        acceptedModel = new DefaultTableModel(new String[]{"ID", "Name", "Vehicle Type", "Plate Number", "Floor"}, 0);
        acceptedTable = new JTable(acceptedModel);
        JScrollPane acceptedScrollPane = new JScrollPane(acceptedTable);
        acceptedPanel.add(acceptedScrollPane, BorderLayout.CENTER);

        deleteAcceptedButton = new JButton("Delete Booking");
        JPanel acceptedButtonPanel = new JPanel();
        acceptedButtonPanel.add(deleteAcceptedButton);
        acceptedPanel.add(acceptedButtonPanel, BorderLayout.SOUTH);

        tabbedPane.addTab("Accepted Bookings", acceptedPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Tombol Logout
        logoutButton = new JButton("Logout");
        mainPanel.add(logoutButton, BorderLayout.SOUTH);

        // Load data dari database
        loadPendingBookings();
        loadAcceptedBookings();

        // Action listener untuk tombol accept
        acceptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = pendingTable.getSelectedRow();
                if (selectedRow != -1) {
                    try (Connection conn = DatabaseConnection.getConnection()) {
                        int bookingId = (int) pendingModel.getValueAt(selectedRow, 0);
                        String query = "UPDATE bookings SET status = 'accepted' WHERE id = ?";
                        PreparedStatement stmt = conn.prepareStatement(query);
                        stmt.setInt(1, bookingId);
                        stmt.executeUpdate();

                        // Pindahkan data ke tabel accepted
                        Object[] rowData = new Object[5];
                        for (int i = 0; i < 5; i++) {
                            rowData[i] = pendingModel.getValueAt(selectedRow, i);
                        }
                        acceptedModel.addRow(rowData);

                        // Hapus data dari tabel pending
                        pendingModel.removeRow(selectedRow);

                        JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Booking accepted successfully.");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Error updating booking: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Please select a booking to accept.");
                }
            }
        });

        // Action listener untuk tombol delete (Pending)
        deletePendingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = pendingTable.getSelectedRow();
                if (selectedRow != -1) {
                    try (Connection conn = DatabaseConnection.getConnection()) {
                        int bookingId = (int) pendingModel.getValueAt(selectedRow, 0);
                        String query = "DELETE FROM bookings WHERE id = ?";
                        PreparedStatement stmt = conn.prepareStatement(query);
                        stmt.setInt(1, bookingId);
                        stmt.executeUpdate();

                        pendingModel.removeRow(selectedRow);

                        JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Booking deleted successfully.");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Error deleting booking: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Please select a booking to delete.");
                }
            }
        });

        // Action listener untuk tombol delete (Accepted)
        deleteAcceptedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = acceptedTable.getSelectedRow();
                if (selectedRow != -1) {
                    try (Connection conn = DatabaseConnection.getConnection()) {
                        int bookingId = (int) acceptedModel.getValueAt(selectedRow, 0);
                        String query = "DELETE FROM bookings WHERE id = ?";
                        PreparedStatement stmt = conn.prepareStatement(query);
                        stmt.setInt(1, bookingId);
                        stmt.executeUpdate();

                        acceptedModel.removeRow(selectedRow);

                        JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Accepted booking deleted successfully.");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Error deleting accepted booking: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(AdminDashboardFrame.this, "Please select a booking to delete.");
                }
            }
        });

        // Action listener untuk tombol logout
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(AdminDashboardFrame.this, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    dispose();
                    new LoginFrame().setVisible(true);
                }
            }
        });
    }

    private void loadPendingBookings() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM bookings WHERE status = 'pending'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                pendingModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("vehicle_type"),
                        rs.getString("plate_number"),
                        rs.getString("floor")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading pending bookings: " + ex.getMessage());
        }
    }

    private void loadAcceptedBookings() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM bookings WHERE status = 'accepted'";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                acceptedModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("vehicle_type"),
                        rs.getString("plate_number"),
                        rs.getString("floor")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading accepted bookings: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminDashboardFrame().setVisible(true));
    }
}
