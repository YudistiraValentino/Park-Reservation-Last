/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parkreservation;

public class Booking {
    private String name;
    private String vehicleType;
    private String plateNumber;
    private String floor;

    public Booking(String name, String vehicleType, String plateNumber, String floor) {
        this.name = name;
        this.vehicleType = vehicleType;
        this.plateNumber = plateNumber;
        this.floor = floor;
    }

    public String getName() {
        return name;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public String getFloor() {
        return floor;
    }
}


