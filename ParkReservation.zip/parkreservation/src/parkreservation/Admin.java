package parkreservation;

public class Admin extends User {
    public Admin(String username, String password) {
        super(username, password);
    }

    // Admin-specific methods can go here, e.g., manage parking slots
}
