package parkreservation;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DashboardFrame extends JFrame {

    // ArrayList untuk menyimpan data reservasi
    private ArrayList<Reservation> reservations = new ArrayList<>();

    // Tabel untuk menampilkan data reservasi
    private JTable reservationTable;
    private DefaultTableModel tableModel;

    public DashboardFrame() {
        setTitle("Dashboard - Park Reservation");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel untuk form input
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(5, 2));

        JLabel customerNameLabel = new JLabel("Customer Name:");
        JTextField customerNameField = new JTextField();
        inputPanel.add(customerNameLabel);
        inputPanel.add(customerNameField);

        JLabel vehicleTypeLabel = new JLabel("Vehicle Type (Car/Bike):");
        JTextField vehicleTypeField = new JTextField();
        inputPanel.add(vehicleTypeLabel);
        inputPanel.add(vehicleTypeField);

        JLabel plateNumberLabel = new JLabel("Plate Number:");
        JTextField plateNumberField = new JTextField();
        inputPanel.add(plateNumberLabel);
        inputPanel.add(plateNumberField);

        JLabel floorLabel = new JLabel("Floor:");
        JTextField floorField = new JTextField();
        inputPanel.add(floorLabel);
        inputPanel.add(floorField);

        JButton bookButton = new JButton("Book Parking");
        inputPanel.add(bookButton);

        // Add inputPanel to the frame
        add(inputPanel, BorderLayout.NORTH);

        // Tabel untuk menampilkan data reservasi
        String[] columnNames = {"Customer Name", "Vehicle Type", "Plate Number", "Floor"};
        tableModel = new DefaultTableModel(columnNames, 0);
        reservationTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(reservationTable);
        add(scrollPane, BorderLayout.CENTER);

        // Action listener untuk tombol Book Parking
        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mendapatkan data dari form
                String customerName = customerNameField.getText().trim();
                String vehicleType = vehicleTypeField.getText().trim();
                String plateNumber = plateNumberField.getText().trim();
                int floor = Integer.parseInt(floorField.getText().trim());

                // Validasi input
                if (customerName.isEmpty() || vehicleType.isEmpty() || plateNumber.isEmpty() || floor <= 0) {
                    JOptionPane.showMessageDialog(DashboardFrame.this, "Please fill all fields correctly.");
                } else {
                    // Menambahkan data ke ArrayList
                    Reservation reservation = new Reservation(customerName, vehicleType, plateNumber, floor);
                    reservations.add(reservation);

                    // Menambahkan data ke tabel
                    tableModel.addRow(new Object[]{customerName, vehicleType, plateNumber, floor});

                    // Clear input fields
                    customerNameField.setText("");
                    vehicleTypeField.setText("");
                    plateNumberField.setText("");
                    floorField.setText("");
                }
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        // Running the DashboardFrame
        SwingUtilities.invokeLater(() -> new DashboardFrame().setVisible(true));
    }
}
