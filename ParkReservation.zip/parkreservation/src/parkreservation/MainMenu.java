package parkreservation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame {

    private JButton adminButton;
    private JButton customerButton;

    public MainMenu(String userType) {
        setTitle("Main Menu");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel untuk menu utama
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));

        JLabel welcomeLabel = new JLabel("Welcome, " + userType + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(welcomeLabel);

        if (userType.equals("Admin")) {
            adminButton = new JButton("Go to Admin Dashboard");
            panel.add(adminButton);

            adminButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Navigasi ke Admin Dashboard
                    dispose();
                    new AdminDashboardFrame().setVisible(true);
                }
            });
        } else if (userType.equals("Customer")) {
            customerButton = new JButton("Go to Customer Dashboard");
            panel.add(customerButton);

            customerButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Navigasi ke Customer Dashboard
                    dispose();
                    new CustomerDashboardFrame().setVisible(true);
                }
            });
        }

        add(panel);
    }
}
