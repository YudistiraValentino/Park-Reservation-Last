package parkreservation;

public class Customer extends User {
    public Customer(String username, String password) {
        super(username, password);
    }

    // Customer-specific methods can go here, e.g., book parking slots
}
