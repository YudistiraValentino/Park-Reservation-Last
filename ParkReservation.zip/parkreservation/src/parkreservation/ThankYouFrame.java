package parkreservation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ThankYouFrame extends JFrame {

    public ThankYouFrame() {
        setTitle("Thank You");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel utama
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Label ucapan terima kasih
        JLabel thankYouLabel = new JLabel("Thank you for booking! Your request will be processed by the admin.", SwingConstants.CENTER);
        thankYouLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(thankYouLabel, BorderLayout.CENTER);

        // Panel untuk tombol
        JPanel buttonPanel = new JPanel();
        JButton bookAgainButton = new JButton("Book Again");
        JButton logoutButton = new JButton("Logout");

        buttonPanel.add(bookAgainButton);
        buttonPanel.add(logoutButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);

        // Action Listener untuk tombol Book Again
        bookAgainButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Tutup Thank You Frame
                new CustomerDashboardFrame().setVisible(true); // Kembali ke Customer Dashboard
            }
        });

        // Action Listener untuk tombol Logout
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Tutup Thank You Frame
                new LoginFrame().setVisible(true); // Kembali ke Login Frame
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ThankYouFrame().setVisible(true));
    }
}
